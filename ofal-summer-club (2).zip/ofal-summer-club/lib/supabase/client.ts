'use client';

import { createBrowserClient } from '@supabase/ssr';

// Client Supabase utilisable dans les Client Components (navigateur).
export function createClient() {
  return createBrowserClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!
  );
}
